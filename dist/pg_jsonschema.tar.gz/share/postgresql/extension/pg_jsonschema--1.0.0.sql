CREATE FUNCTION jsonb_matches_schema(val text, schema text)
RETURNS boolean
AS '$libdir/pg_jsonschema'
LANGUAGE C IMMUTABLE STRICT;
